package br.com.ChatGPT3Project;


public class ChatAnswer {
	
	private String chatAnswer;
	  
	public ChatAnswer() {
	   }
	public String getChatAnswer() {
		      return chatAnswer;
		   }
	public void setChatAnswer(String chatAnswer) {
	      this.chatAnswer = chatAnswer;
	   }

}
