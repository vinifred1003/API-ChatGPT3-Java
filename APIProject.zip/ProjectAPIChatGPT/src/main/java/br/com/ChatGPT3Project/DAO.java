package br.com.ChatGPT3Project;

public interface DAO {
	 void inserir(ChatAnswer chatAnswer);
}
